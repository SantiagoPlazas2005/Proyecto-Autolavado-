package com.autolavado.Autolavado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutolavadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
